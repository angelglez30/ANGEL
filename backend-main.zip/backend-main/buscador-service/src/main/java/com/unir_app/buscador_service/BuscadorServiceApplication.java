package com.unir_app.buscadorservice;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class BuscadorServiceApplication {

    public static void main(String[] args) {
        SpringApplication.run(BuscadorServiceApplication.class, args);
    }
}
