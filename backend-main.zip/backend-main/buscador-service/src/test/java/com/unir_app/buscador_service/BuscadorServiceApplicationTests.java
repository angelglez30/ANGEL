package com.unir_app.buscador_service;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class BuscadorServiceApplicationTests {

	@Test
	void contextLoads() {
	}

}
